<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<table bgcolor="pink" border="1">
		<th>订单数量：</th><th>订单地址：</th><th>订单时间：</th><th>订单总价：</th>
<?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$en): $mod = ($i % 2 );++$i;?><tr>
		<td><?php echo ($en['ordernum']); ?></td>
		<td><?php echo ($en['orderaddress']); ?></td>
		<td><?php echo ($en['ordertime']); ?></td>
		<td><?php echo ($en['orderprice']); ?></td>
	</tr><?php endforeach; endif; else: echo "" ;endif; ?></table>
</body>
</html>