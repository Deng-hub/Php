<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
 	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <tille></title>
	<style type="text/css">
	        h1{
	    font-size:30px;
	    color:#930;
	    text-align:center;
	        }
			*{
				margin: 0;
				padding: 0;
			/*	background-color: pink;*/
			}
			div{
				width: 200px;
				height: 200px;
			}
			.center{
				position: absolute;
				top: 30%;
				left: 50%;
				-webkit-transform: translate(-50%, -50%);
				-moz-transform: translate(-50%, -50%);
				-ms-transform: translate(-50%, -50%);
				-o-transform: translate(-50%, -50%);
				transform: translate(-50%, -50%);
			}
		</style>
  </head>
  
  <body onload="aa()"> 
  <div class="center">
     <h1>个人信息</h1>
     <br>
	 <form method="post"  action="<?php echo U('User/updatePerson');?>" >
	 	<p>
 		 头 像： </p><p><input type="text" name="img" value="<?php echo ($data[0]['img']); ?>"></p>
	 	<p>
		   <lable for="username"> 用 户 名：</label>
		      <input type="text" name="username" id="username" value="<?php echo ($data[0]['username']); ?>"></p>
        <p>
		  <lable for="password"> 密 码：</label>
		     <input type="password" name="password" id="password" value="<?php echo ($data[0]['password']); ?>"></p>
		<p>
		  <lable for="name"> 姓 名：</label>
		  	<input type="text" name="name" id="name" value="<?php echo ($data[0]['name']); ?>"></p>
			<p>
		  <lable for="age"> 年 龄：</label>
		  	<input type="text" name="age" id="age" value="<?php echo ($data[0]['age']); ?>">
		  </p>
		<p>
		   性 别：   <input type="radio" name="sex" id="boy" value="0">男
		    <input type="radio" name="sex" id="girl" value="1">女</p>
	    <p>
		 <lable for="address"> 地 址：</label>
		  	<input type="text" name="address" id="address" value="<?php echo ($data[0]['address']); ?>"></p>
		<p>
		    <lable > 用 户 类 型：</label><lable id="lx"></label></p>
	 		<p><lable > 注 册 时 间：</label><lable id="rtime"><?php echo ($data[0]['rtime']); ?></label>
		</p>

        <p><input type="submit"value="提交">
          <input type="reset"value="清空"></p>
     </form>
  </div>
  </body>
  <script type="text/javascript">
		function show(f){
	        var rd=new FileReader();//创建文件读取对象
	        var files=f.files[0];//获取file组件中的文件
	        rd.readAsDataURL(files);//文件读取装换为base64类型
	        rd.onloadend = function(e) {
	            //加载完毕之后获取结果赋值给img 
	            document.getElementById("touxiang").src=this.result;
	        }
	    }
	    function aa(){
		    if(<?php echo ($data[0]['sex']); ?>==0){
			var radio=document.getElementsByName("sex");
			radio[0].checked =true;
		    }else{
		    var radio =document.getElementsByName("sex");
		    radio[1].checked = true;
		    }
		    if(<?php echo ($data[0]['type']); ?>==0){
		    document.getElementById("lx").innerHTML="店家";
			}
			else{
			document.getElementById("lx").innerHTML="用户";
			}
	}
</script>
</html>