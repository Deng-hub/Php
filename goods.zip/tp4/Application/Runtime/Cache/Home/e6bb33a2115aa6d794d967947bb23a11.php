<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>addGoodInform.html</h1>
	<form action="<?php echo U('addgood');?>" method="post">
		<table>
			<tr><td>goodname:<input type="text" name="goodname"></td></tr>
			<tr><td>goodimg:<input type="text" name="goodimg"></td></tr>
			<tr><td>goodprice:<input type="text" name="goodprice"></td></tr>
			<tr><td>number:<input type="text" name="number"></td></tr>
			<tr><td>goodtype:<input type="text" name="goodtype"></td></tr>
			<tr><td><input type="submit" name=""></td></tr>
		</table>
	</form>
</body>
</html>