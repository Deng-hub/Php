<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title></title>
		<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
</head>
<body >
<form action="<?php echo U('updateGood',array('goodid'=>$data[0]['goodid']));?>" method="post">
	<table bgcolor="pink">
	<tr><td>商品名：</td><td><input type="text" name="goodname" value="<?php echo ($data[0]['goodname']); ?>"></td></tr>
	<tr><td>商品图：</td><td><input type="text" name="goodimg" value="<?php echo ($data[0]['goodimg']); ?>"></td></tr>
	<tr><td>商品价格：</td><td><input type="text" name="goodprice" value="<?php echo ($data[0]['goodprice']); ?>"></td></tr>
	<tr><td>商品数量：</td><td><input type="text" name="number" value="<?php echo ($data[0]['number']); ?>"></td></tr>
	<tr><td>商品类型：</td><td>
			<select id='statenums' name='goodtype'>
			  <option value=''>--请选择--</option>
			  <option value="1">1</option>
			  <option value="2">2</option>
			  <option value="3">3</option>
			</select></td></tr>
		<tr><td colspan="2"><input type="submit"></td></tr>
		</table>
</form>
</body>
<script type="text/javascript">
		var street="<?php echo ($data[0]['goodtype']); ?>";
		$('#statenums option:contains(' + street + ')').each(function(){
		  if ($(this).val()==street) {
		     $(this).attr('selected',true);
		  }
	});
</script>
</html>