<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<table bgcolor="pink" border="1">
		<th>商品id:</th><th>加入数量份数:</th><th>加入购物车时间:</th><th>商品名:</th><th>商品图片:</th><th>商品单价:</th><th>库存:</th><th>商品类型:</th><th>总价:</th><th>从购物车移除</th><th>购买</th>
<?php if(is_array($carts)): $i = 0; $__LIST__ = $carts;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$cart): $mod = ($i % 2 );++$i;?><tr><td><?php echo ($cart['goodid']); ?></td>
	<td><?php echo ($cart['prenum']); ?></td>
	<td><?php echo ($cart['carttime']); ?></td>
	<td><?php echo ($cart['goodname']); ?></td>
	<td><?php echo ($cart['goodimg']); ?></td>
	<td><?php echo ($cart['goodprice']); ?></td>
	<td><?php echo ($cart['number']); ?></td>
	<td><?php echo ($cart['goodtype']); ?></td>
	<td><?php echo ($cart['goodprice']*$cart['prenum']); ?></td>
	<td><a href="<?php echo U('deleteMyCart',array('cid'=>$cart['cid']));?>">删除购物车</a></td>
	<td><a href="<?php echo U('purchaseMyCart',array('goodid'=>$cart['goodid'],'rid'=>session('user')[0]['rid'],'ordernum'=>$cart['prenum'],'orderaddress'=>session('user')[0]['address'],'orderprice'=>$cart['goodprice']*$cart['prenum'],'cid'=>$cart['cid']));?>">购买</a></td>
</tr><?php endforeach; endif; else: echo "" ;endif; ?>
</table>
</body>
</html>