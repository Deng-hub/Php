<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="registerUser" method="post">
		<table>
			<tr><td>img:<input type="text" name="img"></td></tr>
			<tr><td>username:<input type="text" name="username"></td></tr>
			<tr><td>password:<input type="text" name="password"></td></tr>
			<tr><td>name:<input type="text" name="name"></td></tr>
			<tr><td>age:<input type="text" name="age"></td></tr>
			<tr><td>sex:<input type="text" name="sex"></td></tr>
			<tr><td>address:<input type="text" name="address"></td></tr>
			<tr><td>type:<input type="text" name="type"></td></tr>
			<tr><td><input type="submit"></td></tr>
		</table>
	</form>
</body>
</html>