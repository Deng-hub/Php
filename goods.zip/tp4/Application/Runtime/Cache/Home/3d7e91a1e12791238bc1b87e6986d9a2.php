<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<table border="1">
		<th>商品名</th><th>商品图片</th><th>商品价格</th><th>下单数量</th><th>收单地址</th><th>下单时间</th><th>下单价格</th><th>删除</th>
<?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$en): $mod = ($i % 2 );++$i;?><tr>
	<td><?php echo ($en['goodname']); ?></td>
		<td><?php echo ($en['goodimg']); ?></td>
		<td><?php echo ($en['goodprice']); ?></td>
		<td><?php echo ($en['ordernum']); ?></td>
		<td><?php echo ($en['orderaddress']); ?></td>
		<td><?php echo ($en['ordertime']); ?></td>
		<td><?php echo ($en['orderprice']); ?></td>
		<td><a href="<?php echo U('deleteMyOrder',array('oid'=>$en['oid']));?>">删除记录</a></td>
	</tr><?php endforeach; endif; else: echo "" ;endif; ?>
</table>
</body>
</html>