<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
</head>
<body>
<h1>请登录</h1>
<form>
用户名：<input type="text" name="username" id="username"><br>
密码：<input type="text" name="password" id="password"><br>
<img src="<?php echo U('verifyM');?>"><br>
验证码：<input type="text" name="come" id="come"><br>
<input type="radio" name="type" value="0" id="xuan">店主
<input type="radio" name="type" value="1" id="xuan">用户
<input type="radio" name="type" value="2" id="xuan">管理
<input type="button" value="提交" onclick="login(username.value,password.value,xuan.value,come.value)">
</form>
<a href="showRegister">注册</a>
</body>
<script type="text/javascript">
	function login(str,strr,strrr,come){
	$.post("<?php echo U('login');?>",{str:str,strr:strr,strrr:strrr,come:come},function(arr){
		switch(arr){
			case "0":
			$.post("<?php echo U('failed');?>",function(arr0){
						alert(arr0);
					});
				break
			case "1":
				  window.location.href="<?php echo U('showUser');?>";
				break;
			case "2":
					window.location.href="<?php echo U('showHoster');?>";
				break;
			case "3":
					window.location.href="<?php echo U('showAdministrator');?>";
				break;
			default:
			$.post("<?php echo U('failed');?>",function(arr0){
						alert(arr0);
					});
				break;
		}
	});
}
</script>
</html>