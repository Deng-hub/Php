<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<a href="logoutAdministrator">退出登录</a>
	<table border="1">
<?php if(is_array($users)): $i = 0; $__LIST__ = $users;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$en): $mod = ($i % 2 );++$i;?><tr>
	<td><?php echo ($en['img']); ?></td>
	<td><?php echo ($en['username']); ?></td>
	<td><?php echo ($en['password']); ?></td>
	<td><?php echo ($en['name']); ?></td>
	<td><?php echo ($en['age']); ?></td>
	<td><?php echo ($en['sex']); ?></td>
	<td><?php echo ($en['address']); ?></td>
	<td><?php echo ($en['type']); ?></td>
	<td><?php echo ($en['rtime']); ?></td>
	<td><a href="<?php echo U('deletePerson',array('rid'=>$en['rid'],'type'=>$en['type']));?>">删除</a></td>
</tr><?php endforeach; endif; else: echo "" ;endif; ?>
	</table>
</body>
</html>