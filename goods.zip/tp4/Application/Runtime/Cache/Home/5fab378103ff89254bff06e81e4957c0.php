<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body><h1>欢迎店家： <?php echo session('seller')[0]['name'];?></h1>
	<a href="<?php echo U('Seller/Addshow');?>">添加商品</a>---<a href="<?php echo U('Seller/showSellerInfo');?>">查看/修改我的个人信息</a>---<a href="<?php echo U('Seller/logout');?>">退出登录</a>
	<form action="<?php echo U('Good/selectByAnotherJoin');?>" method="post" >
			<select name="goodtype" id="select">
			  <option value=''>--请选择--</option>
			  <option value="1">1</option>
			  <option value="2">2</option>
			  <option value="3">3</option>
			</select>

	<table border="1">
			<input type="text" name="goodname" id="goodname"><input type="submit"></form>
		<th>商品名</th><th>商品图</th><th>商品价格</th><th>商品数量</th><th>店家id</th><th>商品类型</th><th>查看订单<th>修改</th><th>删除</th>
<?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$en): $mod = ($i % 2 );++$i;?><tr>
		<td><?php echo ($en['goodname']); ?></td>
		<td><?php echo ($en['goodimg']); ?></td>
		<td><?php echo ($en['goodprice']); ?></td>
		<td><?php echo ($en['number']); ?></td>
		<td><?php echo ($en['rid']); ?></td>
		<td><?php echo ($en['goodtype']); ?></td>
		<td><a href="<?php echo U('Seller/showOrder',array('goodid'=>$en['goodid']));?>">查看订单</a></td>
		<td><a href="<?php echo U('Good/showUpdateGoodInfo',array('goodid'=>$en['goodid']));?>">修改</a></td>
		<td><a href="<?php echo U('Good/deleteGood',array('goodid'=>$en['goodid']));?>">删除</a></td>
</tr><?php endforeach; endif; else: echo "" ;endif; ?>
</table>
<?php echo ($show); ?>
</body>
</html>