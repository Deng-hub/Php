<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div align="center">
<table>


	<tr><td>名称：<span><?php echo ($data['goodname']); ?></span></td></tr>
	<tr><td>图片：<span><?php echo ($data['goodimg']); ?></span></td></tr>
	<tr><td>价格：<span><?php echo ($data['goodprice']); ?></span></td></tr>
	<tr><td>库存数量:<span><?php echo ($data['number']); ?></span></td></tr>
	<tr><td>商品类型:<span><?php echo ($data['goodtype']); ?></span></td></tr>
	<tr><td>商品id:<span><?php echo ($data['goodid']); ?></span></td></tr>
	<tr><td>
		<form action="<?php echo U('purchaseMyClick',array('goodid'=>$data['goodid'],'rid'=>session('user')[0]['rid'],'orderaddress'=>session('user')[0]['address'],'goodprice'=>$data['goodprice'],'number'=>$data['number']));?>" method="post">
			<select name="ordernum" id="select">
			  <option value=''>--请选择--</option>
			  <option value="1">1</option>
			  <option value="2">2</option>
			  <option value="3">3</option>
			</select>
			<input type="submit">
		</form>
	</td></tr>
	<tr><td id="price"></td></tr>
</table>
</div>
</body>
<script type="text/javascript">
	var sel=document.getElementById("select");
　　sel.onchange=function(){
　　　　document.getElementById("price").innerHTML="Total :"+(select.options[sel.selectedIndex].value*<?php echo ($data['goodprice']); ?>);
　　}　

</script>
</html>