<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
</head>
<body >
	<h1>欢迎: <?php echo session('user')[0]['name'];?></h1>
	<a href="<?php echo U('Cart/showMyCarts');?>">查看我的购物车</a>
	<a href="<?php echo U('Order/showMyOrders');?>">我的订单</a>
	<a href="<?php echo U('showBsPInfo');?>">查看/修改我的个人信息</a>
	<a href="<?php echo U('User/logout');?>">退出登录</a>
	<form action="<?php echo U('Good/selectByJoin');?>" method="post">
			<select name="goodtype" id="select">
			  <option value=''>--请选择--</option>
			  <option value="1">1</option>
			  <option value="2">2</option>
			  <option value="3">3</option>
			</select>
			<input type="text" name="goodname" id="goodname"><input type="submit"></form>
<table border="1" bgcolor="green">
<th>商品名</th><th>商品图</th><th>商品价格</th><th>商品数量</th><th>店家id</th><th>商品类型</th><th>添加购物车</th><th>购买</th>
<?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$en): $mod = ($i % 2 );++$i;?><tr>
		<td><?php echo ($en['goodname']); ?></td>
		<td><?php echo ($en['goodimg']); ?></td>
		<td><?php echo ($en['goodprice']); ?></td>
		<td><?php echo ($en['number']); ?></td>
		<td><?php echo ($en['rid']); ?></td>
		<td><?php echo ($en['goodtype']); ?></td>
		<td><a href="<?php echo U('Cart/addCartShow',array('goodname'=>$en['goodname'],'goodimg'=>$en['goodimg'],'goodprice'=>$en['goodprice'],'number'=>$en['number'],'goodtype'=>$en['goodtype'],'goodid'=>$en['goodid']));?>">添加购物车</a></td>
		<td><a href="<?php echo U('User/purchaseShow',array('goodname'=>$en['goodname'],'goodimg'=>$en['goodimg'],'goodprice'=>$en['goodprice'],'number'=>$en['number'],'goodtype'=>$en['goodtype'],'goodid'=>$en['goodid']));?>">购买</a></td>
	</tr><?php endforeach; endif; else: echo "" ;endif; ?>
</table>
<?php echo ($show); ?>
</body>

</html>