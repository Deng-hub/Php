<?php
namespace Home\Controller;
use Think\Controller;
class GoodController extends Controller{
	public function selectByJoin(){
		$model=M('goodinfo');
		$se['goodtype']=I('request.goodtype');
		$se['goodname']=array('like',"%".I('request.goodname')."%");
		if($se['goodtype']==''){
			unset($se['goodtype']);
		}
		$da=$model->where($se)->count();
		$Page=new \Think\Page($da,5);
		$ae['goodtype']=I('request.goodtype');
		$ae['goodname']=I('request.goodname');
		if($ae['goodtype']==''){
			unset($ae['goodtype']);
		}
		foreach ($ae as $key => $value){
			$Page->parameter[$key]=$value;
		}
		$p=isset($_GET['p'])?$_GET['p']:1;
		$this->data=$model->where($se)->Page($p.',5')->select();
		$this->show=$Page->show();
		$this->display('User/goodinform');
	}
	public function selectByAnotherJoin(){
		$model=M('goodinfo');
		$se['rid']=session('seller')[0]['rid'];
		$se['goodtype']=I('request.goodtype');
		if($se['goodtype']==''){
			unset($se['goodtype']);
		}
		$se['goodname']=array('like',"%".I('request.goodname')."%");
		$da=$model->where($se)->count();
		$Page=new \Think\Page($da,5);
		$ae['rid']=session('seller')[0]['rid'];
		$ae['goodtype']=I('request.goodtype');
		if($ae['goodtype']==''){
			unset($ae['goodtype']);
		}
		$ae['goodname']=I('request.goodname');
		foreach ($ae as $key => $value){
			$Page->parameter[$key]=$value;
		}
		$p=isset($_GET['p'])?$_GET['p']:1;
		$this->data=$model->where($se)->Page($p.',5')->select();
		$this->show=$Page->show();
		$this->display('Seller/showSellerGoods');
	}
	public function showUpdateGoodInfo(){
		$model=M('goodinfo');
		$arr['goodid']=I('get.goodid');
		$data=$model->where($arr)->select();
		$this->data=$model->where($arr)->select();
		$this->display('showGoodInfo');
	}
	public function updateGood(){
		$model=M('goodinfo');
		$arr['goodid']=I('get.goodid');
		$da=$model->create();
		$data=$model->where($arr)->save($da);
		if($data){
			$this->success('修改成功',U('User/showHoster'));
		}
	}
	public function deleteGood(){
		$model=M('goodinfo');
		$arr['goodid']=I('get.goodid');
		if($model->where($arr)->delete()){
			$this->success('删除成功',U('User/showHoster'));
		}
	}
}
?>