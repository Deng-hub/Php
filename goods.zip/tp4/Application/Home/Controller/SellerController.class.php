<?php
namespace Home\Controller;
use Think\Controller;
use UserController;
/**
 * 
 */
class SellerController extends Controller
{
	public function addgood(){
		$model=M('goodinfo');
		$data=$model->create();
		$data['rid']=session('seller')[0]['rid'];
		$very=$model->add($data);
		if($very){
			$this->success('添加成功',U('User/showHoster'));
		}
	}
	public function addShow(){
		$this->display('addGoodInform');
	}
	public function showSellerInfo(){
		$model=M('userregister');
		$arr['rid']=session('seller')[0]['rid'];
		$data=$model->where($arr)->select();
		$this->assign('data',$data);
		$this->display('showSellerInfo');
	}
	public function logout(){
		unset($_SESSION['seller']);
		$this->success("退出成功",U('User/showlogin'));
	}
	public function showOrder(){
		$model=M('order');
		$arr['goodid']=I('get.goodid');
		$this->data=$model->where($arr)->select();
		$this->display('showSellerOrders');
	}
	
}
?>