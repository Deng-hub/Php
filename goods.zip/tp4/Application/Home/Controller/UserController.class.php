<?php
namespace Home\Controller;
use Think\Controller;
class UserController extends Controller{
	public function showlogin(){
		$this->display('user');
	}

	public function verifyM(){
		$vf=new \Think\Verify();
        $vf->entry();
	}
	public function checks(){
		$vf=new \Think\Verify();
        return $vf->check($_POST['come'],$id='');
	}

	//用户登录并判断管理员
	public function login(){
		$model=M('userregister');
		$model->create();
		$arr['username']=$_POST['str'];
		$arr['password']=$_POST['strr'];
		$arr['type']=$_POST['strrr'];
		$data=$model->where($arr)->select();
		if($data&&$this->checks()){
			if($arr['type']==1){
			session('user',$data);
			$this->ajaxReturn("1");
		}
			else if($arr['type']==0){
				session('seller',$data);
				$this->ajaxReturn("2");
			}
			else if($arr['type']==2){
				session('administrator',$data);
				$this->ajaxReturn("3");
			}
		}else{
			$this->ajaxReturn("0");
		}
	}
	//登录成功展示商品信息
	public function showUser(){
		$model=M('goodinfo');
		$user=$model->create();
		$num=$model->count();
		$Page=new \Think\Page($num,10);
		$_GET['p']=isset($_GET['p'])?$_GET['p']:1;
		$this->data=$model->page($_GET['p'].',10')->select();
		$this->show=$Page->show();
		$this->display('goodinform');
	}
	public function showHoster(){
		$model=M('goodinfo');
		$condition['rid']=session('seller')[0]['rid'];
		$num=$model->where($condition)->count();
		$Page=new \Think\Page($num,10);
		$_GET['p']=isset($_GET['p'])?$_GET['p']:1;
		$this->data=$model->where($condition)->page($_GET['p'].',10')->select();
		$this->show=$Page->show();
		$this->display('Seller/showSellerGoods');
	}
	public function showAdministrator(){
		$model=M('userregister');
		$condition['rid']=session('administrator')[0]['rid'];
		$num=$model->count();
		$Page=new \Think\Page($num,10);
		$_GET['p']=isset($_GET['p'])?$_GET['p']:1;
		$this->users=$model->page($_GET['p'].',10')->select();
		$this->show=$Page->show();
		$this->display('showUsersInfo');
	}
	public function failed(){
		echo "登录失败";
	}
	public function registerUser(){
		$model=M('userregister');
		$model->create();
		$model->rtime=date('Y-m-d h:i:s', time());
		$verify=$model->add();
		if($verify){
			echo "registe successfully!";
		}
	}
	public function showRegister(){
		$this->display('addUser');
	}
	public function logout(){
		unset($_SESSION['user']);
		$this->success("退出成功",U('showlogin'));
	}
	public function purchaseShow(){
		$data=I('get.');
		$this->assign('data',$data);
		$this->display('User/showPurchase');
	}
	public function purchaseMyClick(){
		$model=M('order');
		M()->startTrans();
		try{
		$num=$model->create();
		if($num['ordernum']==0){
			echo "<SCRIPT language=JavaScript>alert('请选择加购买产品数量!');</SCRIPT>";
		}else if($_GET['number']==0){
			echo "<SCRIPT language=JavaScript>alert('该产品已卖光!');</SCRIPT>";
		}else{
		$data['goodid']=$_GET['goodid'];
		$data['rid']=session('user')[0]['rid'];
		$data['ordernum']=$num['ordernum'];
		$data['orderaddress']=$_GET['orderaddress'];
		$data['ordertime']=date('Y-m-d h:i:s',time());
		$data['goodprice']=$_GET['goodprice'];
		$data['orderprice']=$data['ordernum']*$data['goodprice'];
		
		$mo=M('goodinfo');
		$arr['goodid']=$_GET['goodid'];
		$oldNum=$mo->where($arr)->getField('number');
		$nowNum=$oldNum-$data['ordernum'];
		if($nowNum<0){
			echo "<SCRIPT language=JavaScript>alert('库存不足!');</SCRIPT>";
		}else{
		$data=$model->add($data);
		$mo->where(['goodid'=>$_GET['goodid']])->save(['number'=>$nowNum]);
		M()->commit();
		$this->success('购物成功',U('User/showUser'));
	}
		}
	}catch (\Exception $e){
			M()->rollback();//回滚
            $this->error('购买失败',U('User/showUser'));
		}
	}
	public function showBsPInfo(){
		$model=M('userregister');
		$arr['rid']=session('user')[0]['rid'];
		$data=$model->where($arr)->select();
		$this->assign('data',$data);
		$this->display('showMyInfo');
	}
	public function updatePerson(){
		$model=M('userregister');
		$data=$model->create();
		$model->username=$data['img'];
		$model->username=$data['username'];
		$model->password=$data['password'];
		$model->name=$data['name'];
		$model->age=$data['age'];
		$model->sex=$data['sex'];
		$model->address=$data['address'];
		$arr=array('rid'=>session('user')[0]['rid']);
		if($model->where($arr)->save()){
			session(null);
			$this->display('user');
		}
	}
	public function deletePerson(){
		$arr['rid']=$_GET['rid'];
		$arr['type']=$_GET['type'];
		if($arr['type']==1){
		$model=M();
		$arr['rid']=$_GET['rid'];
		$sql="delete goods_userregister,goods_order,goods_cart from (goods_userregister left join goods_order on goods_userregister.rid=goods_order.rid) left join goods_cart on goods_userregister.rid=goods_cart.rid where goods_userregister.rid='".$arr['rid']."'";
		$da=$model->execute($sql);
		if($da){
			$this->success('删除成功',U('showAdministrator'));
		}
	}else if($arr['type']==0){
		$model=M();
		$arr['rid']=$_GET['rid'];
		$sql="delete goods_goodinfo,goods_userregister from goods_goodinfo left join goods_userregister on goods_goodinfo.rid=goods_userregister.rid where goods_userregister.rid='".$arr['rid']."'";
		$result=$model->execute($sql);
		if($result){
			$this->success('删除成功',U('showAdministrator'));
		}
	}
	}
	public function logoutAdministrator(){
		unset($_SESSION['administrator']);
		$this->success("退出成功",U('showlogin'));
	}
}
?>