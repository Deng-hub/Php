<?php
namespace Home\Controller;
use Think\Controller;
class OrderController extends Controller{
	public function showMyOrders(){
		$model=M('order');
		$arr['goods_order.rid']=session('user')[0]['rid'];
		$this->data=$model->join("goods_goodinfo on goods_order.goodid=goods_goodinfo.goodid",left)->where($arr)->select();
		$this->display('myOrders');
	}
	public function deleteMyOrder(){
		$model=M('order');
		$arr['oid']=I('get.oid');
		$data=$model->where($arr)->delete();
		if($data){
			$this->success("删除成功");
		}
	}
}
?>