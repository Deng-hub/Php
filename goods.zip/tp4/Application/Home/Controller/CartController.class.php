<?php
namespace Home\Controller;
use Think\Controller;
class CartController extends Controller{
	public function addCartShow(){
		$data=I('get.');
		$this->assign('data',$data);
		$this->display('showClickCart');
	}
	public function addCart(){

		$model=M('cart');
		$data=$model->create();
		if($data['prenum']==0){
			echo "<SCRIPT language=JavaScript>alert('请选择加入购物车产品数量!');</SCRIPT>";
		}
		else{
		$data['rid']=session('user')[0]['rid'];
		$data['goodid']=I('get.rid');
		$data['carttime']=date('Y-m-d h:i:s', time());
		$retu=$model->add($data);
		if($retu){
				$this->success('添加购物车成功',U('Cart/showMyCarts'));
		}
	}
	}
	public function showMyCarts(){
		$model=M('cart');
		$arr['goods_cart.rid']=session('user')[0]['rid'];
		 // $result=$model->field('ren.name,ren.city,xuesheng.address')->join("xuesheng on xuesheng.name=ren.name")->select();
		$this->carts=$model->join("goods_goodinfo on goods_cart.goodid=goods_goodinfo.goodid",left)->where($arr)->select();
		$this->display('showMyCarts');
	}
	public function deleteMyCart(){
		$model=M('cart');
		$arr['cid']=I('get.cid');
		$data=$model->where($arr)->delete();
		if($data){
			$this->success('删除成功');
		}
	}
	
	public function purchaseMyCart(){
		try {
		$model=M('order');
		$_GET['ordertime']=date('Y-m-d h:i:s',time());

		$mo=M('goodinfo');
		$arr['goodid']=$_GET['goodid'];
		$oldNum=$mo->where($arr)->getField('number');
		$nowNum=$oldNum-$_GET['ordernum'];
		if($nowNum<0){
			echo "<SCRIPT language=JavaScript>alert('库存不足!');</SCRIPT>";
		}else{
		$data=$model->add(I('get.'));
		$mo->where(['goodid'=>$_GET['goodid']])->save(['number'=>$nowNum]);
		M()->commit();
		$md=M('cart');
		$adc['cid']=I('get.cid');
		$data=$md->where($adc)->delete();
		if($data){
		$this->success('购物成功',U('User/showUser'));
	}
		}}catch (\Exception $e) {
			M()->rollback();//回滚
			echo "<SCRIPT language=JavaScript>alert('购买失败!');</SCRIPT>";
		}
	}
		//$data=$model->add(I('get.'));
		// if($data){
		// 	$this->success('购物成功',U('User/showUser'));
		// }
}
?>