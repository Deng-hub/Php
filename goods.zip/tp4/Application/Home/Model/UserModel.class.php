<?php
protected $_validate=array(
		array('come','require','请输入验证码'),
		array('come','checks','验证码错误',1,'callback',1),
		array('username','require','请输入名字'),
		array('username',array('2','3'),'用户长度必须2-3位',1,'length',1),
	);
?>