<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php if($_SESSION['user']['type'] == '0'): ?><h1>管理员: <?php echo session('user')['username'];?>你好!现在是<?php echo date('Y-m-d H:i:sa', time());?><br>
			<a href="<?php echo U('Message/showMessage');?> " target="name"></a>
			<iframe src="Message/addMessage" target="name"></iframe>
		</h1>
		<?php else: ?>
		<h1>用户: <?php echo session('user')['username'];?>你好!现在是<?php echo date('Y-m-d H:i:sa', time());?><br>
			<div>
		</div>
		</h1><?php endif; ?>
</html>