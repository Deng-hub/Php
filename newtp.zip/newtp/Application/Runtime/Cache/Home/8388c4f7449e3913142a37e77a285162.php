<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title></title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<form action="<?php echo U('addMessage');?>" method='post'  enctype="multipart/form-data">
	标题：<input type="text" name="head"><br>
	内容<input type="textarea" name="news"><br>
	图文：<img src="" id="fileUpload"><br>
	<input type="file" name="picture" onchange="show(this)">
	<input type="submit" >
</form>
</body>
<script type="text/javascript">
function show(f){
        var rd = new FileReader();//创建文件读取对象
        var files = f.files[0];//获取file组件中的文件
        rd.readAsDataURL(files);//文件读取装换为base64类型
        rd.onloadend = function(e) {
            //加载完毕之后获取结果赋值给img
            document.getElementById("fileUpload").src = this.result;
        }
    }
</script>
</html>