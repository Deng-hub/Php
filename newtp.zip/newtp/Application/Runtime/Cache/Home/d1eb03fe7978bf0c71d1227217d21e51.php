<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title></title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
	<style type="text/css">
		.touxiang{
			  width: 34px;
			  height: 34px;
			  display: flex;
			  border-radius: 50%;
			  align-items: center;
			  justify-content: center;
			  overflow: hidden;
		}
	
		.white{
			text-decoration: none;
			color:pink; 
		}
		a{
			text-decoration:none
		}
	</style>

</head>
<body id="cont" οnlοad="load();"><div><a href="<?php echo U('UserLogin/logout',array('rid'=>session('user')['rid']));?>" onclick='return del() ' class="white"><h1>注销此账户</h1></a></div>
<div align="center"><h1>欢迎你:</h1><img src="http://localhost/newtp/touxiang/<?php echo session('user')['img'];?>" class="touxiang"><h3 align="center"><?php echo session('user')['name'];?></h3></div>
	<a href="<?php echo U('addM');?>" id="PH">发布NEWS</a>---------------------<a href="<?php echo U('showMessage');?>">查看所有</a>---------------------<a href="<?php echo U('UserLogin/exit');?>">退出登录</a>------------------<a href="<?php echo U('UserLogin/showPerson');?>">查看/修改个人信息</a>----------<a href="<?php echo U('showMessage1');?>" id="PD">已发布</a>---------查找新闻:<input type="text" name="head"><input type="button" value="查找" onclick="showSelect()">----------<br>
	<table border="1"  bgcolor="pink" align="center"><th>序号</th><th>标题</th><th>图片</th><th>内容</th><th>时间</th><th>删除</th><th>修改</th>
	<?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$en): $mod = ($i % 2 );++$i;?><tr><td><?php echo ($en['nid']); ?></td>
			<td><?php echo ($en['head']); ?></td>
			<td><img src="http://localhost/newtp/news/<?php echo ($en['picture']); ?>"></td>
			<td><?php echo ($en['news']); ?></td><td><?php echo ($en['publishtime']); ?></td><td><a href="<?php echo U('Message/deleteMessage',array('nid'=>$en['nid']));?>" onclick='return del();' id="CD">删除</a></td><td><a href="<?php echo U('updateM',array('nid'=>$en['nid']));?>" id="CD">修改</a></td></tr>
		</tr>
		<tr align="right"><td colspan='7'><form method="post">发表评论：<input type="text" ><input type="button"  value="提交" onclick="comment(<?php echo ($en[nid]); ?>,<?php echo session('user')['rid'];?>,getValue(this),this)"></form></td></tr>
		<tr>
			<td colspan='7'><?php if(is_array($comments)): $i = 0; $__LIST__ = $comments;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$cn): $mod = ($i % 2 );++$i; if($cn['nid'] == $en['nid']): ?><h5><img src="<?php echo U('Comment/showCommentPic',array('rid'=>$cn['uid']));?>"><div id="CG">用户</div><?php echo ($cn['uid']); ?> 评论了新闻  <?php echo ($en['head']); ?>：
				<< <a href="<?php echo U('Comment/deleteComment',array('cid'=>$cn['cid']));?>" id="CD">delete</a></h5><?php echo ($cn['comments']); ?>  <br>-----------------------------------------<br><?php else: endif; endforeach; endif; else: echo "" ;endif; ?>
	</td>
</tr><?php endforeach; endif; else: echo "" ;endif; ?>
</table>
<h1><?php echo ($show); ?></h1>
</body>
<script type="text/javascript">
	function comment(nid,uid,com,obj){
		$.post("<?php echo U('Comment/addComments');?>",{nid:nid,uid:uid,com:com},function(arr){
		if(arr>0){
			//alert("评论成功");
			location.reload();
		}
		});
	}
	function getValue(obj){
		var a= $(obj).prev().val();
		return a;
	}
function del()
{
  if(confirm("确定要删除吗？"))
  {
    return true;
  }
  else
  {
    return false;
  }
}
function showSelect(){
	
	var str=document.getElementsByName("head");
	var headstr=str[0].value;
	 //window.location.href='"<?php echo U('selectMessage',array('headstr'=>"+headstr+"));?>"';
	$.post("<?php echo U('selectMessage');?>",{headstr:headstr},function(arr){
		document.getElementById('cont').innerHTML="";
		document.write(arr);
	});
}
window.onload = function(){
       if(<?php echo session('user')['type'];?>==1){
       	  document.getElementById('PH').style.display="none";
       	  document.getElementById('PD').style.display="none";
       	  //document.getElementById('ND').style.display="none";
       	  //document.getElementById('NM').style.display="none";
       	  //document.getElementById('CD').style.display="none";
       	  //var div_ls=document.getElementsByTagName('a');    
		    var aDiv=document.getElementsByTagName("a");

			for (var i=0;i<aDiv.length;i++){
			if(aDiv[i].id=='CD'){
				aDiv[i].style.display="none";
			 }
			}
}
       else{
       	 document.getElementById('PH').style.display="block";
       }
    }
</script>
</script>
</html>