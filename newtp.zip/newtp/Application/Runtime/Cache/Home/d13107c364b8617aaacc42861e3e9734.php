<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title></title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	  <style type="text/css">
			*{
				margin: 0;
				padding: 0;
				background-color: pink;
			}
			
			div{
				width: 200px;
				height: 200px;
			}
			
			.center{
				position: absolute;
				top: 30%;
				left: 50%;
				-webkit-transform: translate(-50%, -50%);
				-moz-transform: translate(-50%, -50%);
				-ms-transform: translate(-50%, -50%);
				-o-transform: translate(-50%, -50%);
				transform: translate(-50%, -50%);
			}
		</style>
</head>
<body>
<div class="center">
<form method="post" action="<?php echo U('register_add');?>" enctype="multipart/form-data">
	img:<input type="file" name="img"><br>
	username:<input type="text" name="username"><br>
	password:<input type="text" name="password"><br>
	name:<input type="text" name="name"><br>
	age:<input type="text" name="age"><br>
	sex:<input type="text" name="sex"><br>
	address:<input type="text" name="address"><br>
	type:<input type="text" name="type"><br>
	<input type="submit">
	</div>
</form>
</body>
</html>