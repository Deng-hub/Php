<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
</head>
<body>
<form action="<?php echo U('updateMessage',array('nid'=>$data[0]['nid']));?>" method='post'  enctype="multipart/form-data">
	标题：<input type="text" name="head" value="<?php echo ($data[0]['head']); ?>"><br>
	内容<input type="textarea" name="news" value="<?php echo ($data[0]['news']); ?>"><br>
	图片<img src="http://localhost/newtp/news/<?php echo ($data[0]['picture']); ?>" id="fileUpload"><br>
	选择修改图文：<input type="file" name="picture"  onchange="show(this)"><br>
	<input type="submit" >
</form>
<script type="text/javascript">
function show(f) {
        var rd = new FileReader();//创建文件读取对象
        var files = f.files[0];//获取file组件中的文件
        rd.readAsDataURL(files);//文件读取装换为base64类型
        rd.onloadend = function(e) {
            //加载完毕之后获取结果赋值给img
            document.getElementById("fileUpload").src = this.result;
        }
    }

</script>
</body>
</html>