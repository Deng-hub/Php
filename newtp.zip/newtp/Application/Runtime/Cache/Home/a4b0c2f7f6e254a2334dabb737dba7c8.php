<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title></title>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	 <style type="text/css">
			*{
				margin: 0;
				padding: 0;
				background-color:pink;
			}
			
			div{
				width: 200px;
				height: 200px;
			}
			
			.center{
				position: absolute;
				top: 50%;
				left: 50%;
				-webkit-transform: translate(-50%, -50%);
				-moz-transform: translate(-50%, -50%);
				-ms-transform: translate(-50%, -50%);
				-o-transform: translate(-50%, -50%);
				transform: translate(-50%, -50%);
			}
		</style>
</head>
<body>

<div class="center">
	<h1>Welcome to this login page HAVE~FUN!</h1>
<form method='post' action="<?php echo U('login_select');?>">
	username: <input type="text" name="username"><br>
	password: <input type="text" name="password"><br>
	type: <input type="text" name="type"><br>
	<input type="submit"><a href="<?php echo U('UserLogin/register');?>">注册账户</a>
</form>
</div>
</body>
</html>