<?php
namespace Home\Controller;
use Think\Controller;
class MessageController extends Controller{
	public function showMessage(){
		$news=M('newsmessage');
		// $arr['uid']=session('user')['rid'];
		//where($arr)->
		$count=$news->count();
		$Page=new \Think\Page($count,3);
		$p=isset($_GET['p'])?$_GET['p']:1;
		$this->data=$news->page($p.',3')->select();
		$this->show=$Page->show();
		$comments=M('comments');
		$this->comments=$comments->select();
		$this->display();
	}
	public function showMessage1(){
		$news=M('newsmessage');
		// $arr['uid']=session('user')['rid'];
		//where($arr)->
		$arr['uid']=session('user')['rid'];
		$count=$news->where($arr)->count();
		$Page=new \Think\Page($count,3);
		$p=isset($_GET['p'])?$_GET['p']:1;
		$map['uid']=session('user')['rid'];
		foreach($map as $key => $value) {
          $Page->parameter[$key]=$value;
        }
		$this->data=$news->where($arr)->page($p.',3')->select();
		$this->show=$Page->show();
		$comments=M('comments');
		$this->comments=$comments->select();
		$this->display('showMessage');
	}
	public function addM(){
		$this->display('addMessage');
	}
	public function addMessage(){
	$upload = new \Think\Upload();
    $upload->maxSize=3145728;
    $upload->exts=array('jpg', 'gif', 'png', 'jpeg');
    $upload->rootPath='./Uploads/';
    $upload->autoSub=false;
    // 上传文件 
    $info=$upload->upload();
    if(!$info) {// 上传错误提示错误信息
        $this->error($upload->getError());
    }else{// 上传成功
      	$news=M('newsmessage');
		$arr=$news->create();
		$arr['picture']=$info['picture']['savename'];
		$arr['uid']=session('user')['rid'];
		$arr['publishtime']=date('Y-m-d H:i:sa', time());
		$da=$news->add($arr);
		if($da){
		$image=new \Think\Image();
		$image->open('./Uploads/'.$arr['picture']);
	 	$image->thumb(220,220)->save('./news/'.$arr['picture']);
		$this->success('添加成功',U('Home/Message/showMessage'));
		}
    }
	}
	public function deleteMessage(){
		$mess=M('newsmessage');
		$data=$mess->create();
		$data['nid']=I('get.nid');
		$da=$mess->where($data)->delete();
		if($da){
		$this->success('删除成功',U('Home/Message/showMessage'));
		}
	}
	public function updateMessage(){
	$upload = new \Think\Upload();
    $upload->maxSize=3145728 ;
    $upload->exts=array('jpg', 'gif', 'png', 'jpeg');
    $upload->rootPath='./Uploads/';
    $upload->autoSub=false;
    // 上传文件 
    $info=$upload->upload();
    if(!$info) {// 上传错误提示错误信息
        $this->error($upload->getError());
    }else{// 上传成功
      	$news=M('newsmessage');
		$data=$news->create();
		$da=array('nid'=>I('get.nid'));
		$all=$news->where($da)->select();
		$news->picture=$info['picture']['savename'];
		$news->publishtime=$all[0]['publishtime'].'  update'.date('Y-m-d H:i:sa',time());
		$da=$news->where($da)->save();
		if($da){
		$image=new \Think\Image();
		$image->open('./Uploads/'.$info['picture']['savename']);
	 	$image->thumb(220,220)->save('./news/'.$info['picture']['savename']);
		$this->success('修改成功',U('Home/Message/showMessage'));
		}
    }
	}
	public function updateM(){
		$arr['nid']=I('get.nid');
		$mess=M('newsmessage');
		$this->data=$mess->where($arr)->select();
		$this->display('updateMessage');
	}
	public function selectMessage(){
		$model=M('newsmessage');
		$mess['head']=array('like',"%".$_POST['headstr']."%");
		$count=$model->where($mess)->count();
		$page=new \Think\Page($count,3);
		$map['head']=$_POST['headstr'];
		foreach ($map as $key =>$value) {
			$page->parameter[$key]=$value;
		}
		$comments=M('comments');
		$this->comments=$comments->select();
		$this->data=$model->where($mess)->page($_GET['p'].',3')->select();
		$this->show=$page->show();
		//echo $this->fetch('showMessage');
		$this->display('showMessage');
	}
}
?>