<?php
namespace Home\Controller;
use Think\Controller;

class UserLoginController extends Controller{
	public function login(){
	$this->display();
	}
	public function register(){
	$this->display();
	}
	public function login_select(){
		$model=M('register');
		$data=$model->create();
		$da=$model->where($data)->find();
		if($da){
			session("user",$da);
			$this->success("登录成功",U('Message/showMessage'));
		}
		else{
			$this->error("登录失败请重新登录");
		}
	}
	public function register_add()
	{
		$upload = new \Think\Upload();
	    $upload->maxSize=3145728;
	    $upload->exts=array('jpg', 'gif', 'png', 'jpeg');
	    $upload->rootPath='./Uploads/';
	    $upload->autoSub=false;
	    // 上传文件 
	    $info=$upload->upload();
	    if(!$info) {// 上传错误提示错误信息
	        $this->error($upload->getError());
	    }else{
		$model=M('register');
		$data=$model->create();
		$data['img']=$info['img']['savename'];
		$data['rtime']=date('Y-m-d H:i:sa', time());
		$image=new \Think\Image();
		$image->open('./Uploads/'.$data['img']);
	 	$image->thumb(100,100)->save('./touxiang/'.$data['img']);
	 	$image->thumb(20,20)->save('./commentspics/'.$data['img']);
		if($model->add($data)){
			$this->display('login');
		}
		else{
			$this->display();
		}
	}
}
	public function exit(){
		session(null);
		$this->success("退出成功",U('login'));
	}
	public function logout(){
		$model=M('register');
		$data=$model->create();
		$data['rid']=I('get.rid');
		$da=$model->where($data)->delete();
		if($da){
			$this->success("用户注销成功",U('login'));
			session(null);
		}
	}
	public function showPerson(){
		$this->display('personinfo');
	}
	public function updatePerson(){
		$upload=new \Think\Upload();
	    $upload->maxSize=3145728;
	    $upload->exts=array('jpg', 'gif', 'png', 'jpeg');
	    $upload->rootPath='./Uploads/';
	    $upload->autoSub=false;
	    // 上传文件 
	    $info=$upload->upload();
	    if(!$info) {// 上传错误提示错误信息
	        $this->error($upload->getError());
	    }else{
		$model=M('register');
		$data=$model->create();
		$model->img=$info['filename']['savename'];
		$model->username=$data['username'];
		$model->password=$data['password'];
		$model->name=$data['name'];
		$model->age=$data['age'];
		$model->sex=$data['sex'];
		$model->address=$data['address'];
		$image=new \Think\Image();
		$image->open('./Uploads/'.$info['filename']['savename']);
	 	$image->thumb(100,100)->save('./touxiang/'.$info['filename']['savename']);
	 	$image->thumb(20,20)->save('./commentspics/'.$info['filename']['savename']);
	 	$arr=array('rid'=>session('user')['rid']);
		if($model->where($arr)->save()){
			session(null);
			$this->display('login');
		}
		else{
			echo $model->GetlastSql();
			//$this->error('修改失败',U:(''));
		}
	}
}
}
?>